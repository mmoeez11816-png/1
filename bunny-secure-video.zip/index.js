import express from "express";
import crypto from "crypto";

const app = express();
const PORT = process.env.PORT || 3000;

// Bunny Token Auth Key
const BUNNY_TOKEN_KEY = "facc5d55-dbe4-4e0c-a617-03d5536a0276";

// Function to generate token
function generateToken(videoId) {
  const expires = Math.floor(Date.now() / 1000) + 3600; // 1 hour expiry
  const message = videoId + expires;
  const hash = crypto
    .createHmac("sha256", BUNNY_TOKEN_KEY)
    .update(message)
    .digest("hex");
  return `${hash}_${expires}`;
}

app.get("/get-video", (req, res) => {
  const videoId = "4fe6e1aa-4d4b-426c-ab57-64c1382aacca"; // Your video ID
  const token = generateToken(videoId);
  const iframeUrl = `https://iframe.mediadelivery.net/embed/${videoId}?token=${token}`;
  res.json({ iframeUrl });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
